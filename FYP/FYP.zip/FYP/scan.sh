nmap --script nmap-vulners,vulscan --script-args vulscandb=scipvuldb.csv -sV <target IP>
